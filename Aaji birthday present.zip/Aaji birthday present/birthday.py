from pygame import mixer
import pygame
import sys
import random
pygame.init()

screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
screen_details = pygame.display.Info()
x_ratio = screen_details.current_w/1366
y_ratio = screen_details.current_h/768
originalhead = pygame.image.load('assets/aaji.jpg')
head = pygame.image.load('assets/aaji.jpg')
white = (255, 255, 255)
rando = 0
current_time = 0
chose_time = 0
check = False

clock = pygame.time.Clock()
pygame.display.set_caption('Birthday')
black = (0, 0, 0)
loop = True
background = pygame.image.load('assets/background.png')
background = pygame.transform.scale(
background, (round(1366*x_ratio), round(768*y_ratio)))
font = pygame.font.Font('assets/freesansbold.ttf', 100)


def loadtext3(x):
    text = font.render('Happy Birthday', True, black)
    screen.blit(text, (x, 100))
    text = font.render('Aaji', True, black)
    screen.blit(text, (x+200, 500))


def loadtext2(y):
    text = font.render('Happy Birthday to you', True, black)
    screen.blit(text, (120, y))
    text2 = font.render('Happy Birthday to you', True, black)
    screen.blit(text2, (120, y+800))
    text3 = font.render('Happy Birthday dear', True, black)
    screen.blit(text3, (170, y+1600))
    text4 = font.render('Aaji', True, black)
    screen.blit(text4, (620, y+1700))
    text5 = font.render('Happy Birthday to you', True, black)
    screen.blit(text5, (120, y+2400))


def loadbackground():
    screen.blit(background, (0, 0))


def whitescreen(x):
    screen.fill(x)


def loadtext(x):
    text = font.render(x, True, (0, 0, 0))
    screen.blit(text, (100*x_ratio, 120*y_ratio))


def choice1main():
    texty = 800
    check = True
    choiceloop = True
    coordinates=-2500/x_ratio
    while choiceloop:
        if check:
            mixer.music.load('assets/happy_bday_song.mp3')
            mixer.music.play(1)
            check=False
        whitescreen((255, 255, 255))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                choiceloop = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    choiceloop = False
                    mixer.music.stop()
        texty -= 5.5*y_ratio
        if texty < coordinates:
            choiceloop = False
            mixer.music.stop()
        loadtext2(texty)
        loadbackground()
        pygame.display.update()


def choice2main():
    global head, originalhead
    headx = 0
    heady = 0
    choiceloop = True
    current_time = 0
    chose_time = 0
    head = originalhead
    textxx = screen_details.current_w+100
    check = True
    mixer.music.load('assets/happy_bday_2nd.mp3')
    mixer.music.play(1)
    while choiceloop:
        if check:
            chose_time = pygame.time.get_ticks()
            current_time = pygame.time.get_ticks()
            check = False
        whitescreen((255, 255, 255))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                choiceloop = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    choiceloop = False
                    mixer.music.stop()
        if current_time-chose_time < 3000:
            if headx < 550*x_ratio:
                headx += 15*x_ratio
            if heady < 200*y_ratio:
                heady += 8*y_ratio
            if textxx > 390*x_ratio:
                textxx -= 18*x_ratio
            current_time = pygame.time.get_ticks()
            screen.blit(head, (headx, heady))
            loadtext3(textxx)
        else:
            choiceloop = False
            mixer.music.stop()
        loadbackground()
        pygame.display.update()
        current_time = pygame.time.get_ticks()
        clock.tick(60)


while loop:
    whitescreen(white)
    loadbackground()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            loop = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                loop = False
            if event.key == pygame.K_1:
                choice1main()
            if event.key == pygame.K_2:
                choice2main()
            if event.key == pygame.K_s:
                rando = round(random.randint(1, 2))
                check = True

    if check:
        chose_time = pygame.time.get_ticks()
        check = False

    if rando == 1:
        screen.fill((255, 0, 0))
        loadtext('choice 1 chosen')
        if current_time-chose_time > 3000:
            choice1main()
            rando = 0

    elif rando == 2:
        loadtext('choice 2 chosen')
        white = (0, 0, 255)
        if current_time-chose_time > 3000:
            choice2main()
            rando = 0
    else:
        loadtext('Press s to get an option')
        white = (255, 255, 255)
    current_time = pygame.time.get_ticks()
    pygame.display.update()
    clock.tick(60)

pygame.quit()
sys.exit()
